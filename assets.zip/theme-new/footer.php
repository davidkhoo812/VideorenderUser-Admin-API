                        </div><!--ibox-->
                    </div><!--Col-->
                </div><!--row-->
            </div><!--container-->
        </div><!--wrapper-->
        <div class="footer text-center">
            <div class="pull-right">
                
            </div>
            <div>
                <strong>Copyright</strong> Dynamic Video&copy; 2014-2017
            </div>
        </div>

        </div>
        </div>

    <script>
        $(document).ready(function() {


        });
    </script>

</body>

</html>

<div class="ibox-title">
    <h2>
        LATEST UPDATES
    </h2>
</div>
<div class="ibox-content">
    <div class="search-form">
        <form action="index.html" method="get">
            <div class="input-group">
                <input type="text" placeholder="Admin Theme" name="search" class="form-control input-lg">
                <div class="input-group-btn">
                    <button class="btn btn-lg btn-primary" type="submit">
                        Search
                    </button>
                </div>
            </div>

        </form>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="search-result">
        <h3><a href="#">Project ‘New Marketing Video’ has been created</a></h3>
        <a href="#" class="search-link"> https://www.youtube.com/watch?v=A6Ap9X8SDgU</a>
        <p>2017/08/04 03:30pm</p>
    </div>
    <div class="hr-line-dashed"></div>
    <div class="text-center">
        <div class="btn-group">
            <button class="btn btn-white" type="button"><i class="fa fa-chevron-left"></i></button>
            <button class="btn btn-white">1</button>
            <button class="btn btn-white  active">2</button>
            <button class="btn btn-white">3</button>
            <button class="btn btn-white">4</button>
            <button class="btn btn-white">5</button>
            <button class="btn btn-white">6</button>
            <button class="btn btn-white">7</button>
            <button class="btn btn-white" type="button"><i class="fa fa-chevron-right"></i> </button>
        </div>
    </div>
</div><!--ibox-content-->

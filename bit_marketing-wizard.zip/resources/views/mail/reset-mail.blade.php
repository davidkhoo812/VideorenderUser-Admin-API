<h1>Hi, {{ $name }}</h1>
<p>We got a request to reset your password. To complete your request, please click the link: {{ $link }} </p>
<p>Thanks, Dynamic Video App</p>
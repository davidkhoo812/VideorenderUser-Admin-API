<div class="footer text-center">
            <div class="pull-right">
                
            </div>
            <div>
                <strong>Copyright</strong> Dynamic Video© 2014-2017
            </div>
        </div>
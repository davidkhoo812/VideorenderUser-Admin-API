<footer class="main-footer">
  <div class="pull-right hidden-xs">
    <b>Version</b> 2.4.0
  </div>
  <strong>Copyright &copy; 2017 Dynamic Video</a>.</strong> All rights
  reserved.
</footer>
<h1>Your customer account succesfully created.</h1>
<div>{{ $bodyMessage }}</div>
<p>Sent via {{ $email }}</p>
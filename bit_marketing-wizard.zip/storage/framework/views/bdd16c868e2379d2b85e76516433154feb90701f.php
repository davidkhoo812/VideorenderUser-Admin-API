<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">

<title><?php echo e($title->title); ?> - <?php echo $__env->yieldContent('title'); ?></title>
<!-- Swiper Slider CSS -->
<!-- <link href="<?php echo e(asset('assets/css/swiper.css')); ?>" rel="stylesheet"> -->

<link href="<?php echo e(asset('assets/theme-new/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('assets/theme-new/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/Parsley.js-2.8.0/src/parsley.css')); ?>" rel="stylesheet">

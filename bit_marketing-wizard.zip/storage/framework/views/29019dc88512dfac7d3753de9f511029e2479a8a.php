<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="keywords" content="">
<meta name="author" content="">

<title><?php echo e($title->title); ?> - <?php echo $__env->yieldContent('title'); ?></title>
<!-- Swiper Slider CSS -->

<link href="<?php echo e(asset('assets/theme-new/css/bootstrap.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">

<link href="<?php echo e(asset('assets/theme-new/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/custom_css.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/Parsley.js-2.8.0/src/parsley.css')); ?>" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/datatable/jquery.dataTables.min.css')); ?>">

<link href="<?php echo e(asset('assets/theme-new/css/plugins/steps/jquery.steps.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/plugins/dropzone/basic.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/animate.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css')); ?>" rel="stylesheet">
<!-- FooTable -->
<link href="<?php echo e(asset('assets/theme-new/css/plugins/footable/footable.core.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('assets/theme-new/css/custom.css')); ?>" rel="stylesheet">

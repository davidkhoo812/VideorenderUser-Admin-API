<?php $__env->startSection('title', 'CreateCustomer'); ?>

<?php $__env->startSection('content'); ?>

<section class="content-header">
	<h1>
		View Customer
	</h1>
	<ol class="breadcrumb">
		<li><a href="#"><i class="fa fa-home"></i> Home</a></li>
		<li><a href="#"><i class="fa fa-user"></i> Customer</a></li>
		<li class="active">View Customer</li>
	</ol>
</section>

<!-- Main content -->
<section class="content">
	<div class="row">
		<div class="col-xs-12">
			<div class="box box-success">
				<div class="box-header">
					<h3 class="box-title">View Customer</h3>
				</div>
				<!-- /.box-header -->
				<div class="box-body">
					<table id="customerTable" class="table table-bordered table-striped">
						<cols>
                    		<col width = "10%" >
                    		<col width = "10%" >
                    		<col width = "10%" >
                    		<col width = "15%" >
                    		<col width = "10%" >
                    		<col width = "10%" >
                    		<col width = "10%" >
                    		<col width = "10%" >
                    		<col width = "15%" >
                    	</cols>
						<thead>
						<tr>
							<th>ID</th>
							<th>Account Type</th>
							<th>Name</th>
							<th>Email</th>
							<th>Data Created</th>
							<th>Completed</th>
							<th>Pending</th>
							<th>Active</th>
							<th>Actions</th>
						</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $customersdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
							<tr data-id="<?php echo e($customer->id); ?>">
									<td><?php echo e($customer->id); ?></td>
									<td><?php echo e($customer->type); ?></td>
									<td><?php echo e($customer->name); ?></td>
									<td><?php echo e($customer->email); ?></td>
									<td><?php echo e($customer->created_at); ?></td>
									<?php if($customer->completed_video_num >= 1): ?>
									<td><a href="#" class="video_modal" customerid="<?php echo e($customer->id); ?>" customername="<?php echo e($customer->name); ?>" data-videos="<?php echo e(isset($videosdata[$customer->id]) ? $videosdata[$customer->id] : ''); ?>"><?php echo e($customer->completed_video_num); ?>  Videos</a></td>
									<?php else: ?> <td><?php echo e($customer->completed_video_num); ?>  Videos</td>
									<?php endif; ?>
									<td><?php echo e($customer->rendering_video_num); ?>  Videos</td>
									<td id="customer_status_show"><?php if($customer->status == 1): ?> Yes <?php else: ?> No <?php endif; ?></td>
									<td><a href="<?php echo e(route('admin_edit_customer', [$customer->id])); ?>" class="view-video-hyper"><span class="fa fa-edit"></span></a><a href="#" id="hypercustomerid<?php echo e($customer->id); ?>" customerid="<?php echo e($customer->id); ?>" customertype="<?php echo e($customer->type); ?>" class="transaction_modal view-video-hyper"><span class="fa fa-dollar"></span></a><button type="button" class="btn btn-block btn-primary customer-suspend" data-suspendid="<?php echo e($customer->id); ?>"><?php if($customer->status == 1): ?> Suspend <?php else: ?> Unsuspend <?php endif; ?></button><a href="#" data-id="<?php echo e($customer->id); ?>" class="delete-customer-id view-video-hyper"><span class="fa fa-trash"></span></a></td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
						<tfoot>
						<tr>
							<th>ID</th>
							<th>Account Type</th>
							<th>Name</th>
							<th>Email</th>
							<th>Data Created</th>
							<th>Completed</th>
							<th>Pending</th>
							<th>Active</th>
							<th>Actions</th>
						</tr>
						</tfoot>
					</table>
					<div class="box-footer">
	          <a href="<?php echo e(route('admin_create_customer')); ?>" type="button" class="btn btn-success">Create Customer</a>
	        </div>
				</div>
				<div id="videoModal" class="modal fade">
					<div class="modal-dialog" style="top:25%">
						<div class="modal-content">
							<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h4 class="modal-title">Customer Videos</h4>
							</div>
							<div class="modal-body">
							</div>
						</div>
					</div>
				</div>
				<div id="transactionModal" class="modal fade">
					<div class="modal-dialog" style="top:25%">
						<div class="modal-content">
							<div class="modal-header">
									<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
									<h4 class="modal-title">Customer Transactions</h4>
							</div>
							<div class="modal-body">
								<div class="row">
									<div class="col-md-6">
				            <div class="form-group">
				              <label>Transactions:</label>
				              <p>2017-08-03 12:23PM</p>
				              <p>Transaction ID: 2848939032</p>
				              <p>Payment Processor: PayPal</p>
				              <p>Amount: $99.99</p>
				              <p>Product ID: dynamic-video-premium</p>
				            </div>
				          </div>
				          <div class="col-md-6">
				            <div class="form-group">
				              <label>Change Account Type:</label>
				              <select name="account_type" id="account_type" class="form-control">
				                <option value='Basic'>Basic</option>
				                <option value='Standard'>Standard</option>
				              </select>
				            </div>
				            <input type="hidden" id="accountid"/>
				            <button type="button" id="update_type" class="btn btn-info pull-right">Update</button>
				            <span class="update-type-success">Successfully Updated!</span>
				          </div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
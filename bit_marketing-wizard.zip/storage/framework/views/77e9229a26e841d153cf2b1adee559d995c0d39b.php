
<!--Jquery Library-->
<!--script src="<?php echo e(asset('js/jquery.js')); ?>"></script-->

<!-- Mainly scripts -->
<script src="<?php echo e(asset('assets/theme-new/js/jquery-2.1.1.js')); ?>"></script>
<script src="<?php echo e(asset('assets/theme-new/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/Parsley.js-2.8.0/dist/parsley.js')); ?>"></script>
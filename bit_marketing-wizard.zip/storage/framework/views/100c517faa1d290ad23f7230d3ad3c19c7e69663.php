<?php $__env->startSection('title', 'Lastest Updates'); ?>

<?php $__env->startSection('content'); ?>

<div class="gt_main_content_wrap">
    <section class="gt_about_bg">
        <div class="container">
            <div class="col-lg-12">
            <div class="row">

                <div class="panel panel-default panel_custom_1">
                    <div class="panel-heading">LATEST UPDATES</div>
                    <div class="panel-body">
                        <table id="myTable" class="listing_front_tbl ">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $uservideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uservideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="search-result">
                                
                                <td>Project '<?php echo e($uservideo->title); ?>' has been completed</td>
                                <td class="url"><a href="<?php echo e($uservideo->url); ?>"><?php echo e($uservideo->url); ?></a></td>
                                <td class="meta"><?php echo e($uservideo->created_at); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    
                </div>
            </div>
        </div>


        </div>
    </div>
</section>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<h1>Hi, <?php echo e($name); ?></h1>
<p><?php echo e($bodyMessage); ?> </p>
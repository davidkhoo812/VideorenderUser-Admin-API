<?php $__env->startSection('title', 'User Login'); ?>

<?php $__env->startSection('content'); ?>


<div class="middle-box text-center loginscreen animated fadeInDown">
    <div>
        <div>

            <h1 class="logo-name">DV</h1>

        </div>
        <h3>Welcome to Dynamic Video</h3>
        <p>Hello there! Sign in and start becoming a Dynamic Video!
            <!--Continually expanded and constantly improved Inspinia Admin Them (IN+)-->
        </p>
        <p>Login in. To see it in action.</p>

        <?php if(session()->has('message')): ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <?php echo e(session()->get('message')); ?>

        </div>
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <strong>Success ..! </strong> <?php echo e(Session::get('success')); ?>

        </div>
        <?php elseif(Session::has('error')): ?>
        <div class="alert alert-danger" role="alert">
            <strong>Error ..! </strong> <?php echo e(Session::get('error')); ?>

        </div>
        <?php elseif(count($errors) > 0): ?>
        <div class="alert alert-danger" role="alert">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            <h4 class="text-center"><strong>Error ..! </strong> You have Something Error.</h4>
            <ul class="text-center">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><p style="color: red"><?php echo $error; ?></p></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>

        <?php echo Form::open(['route'=>'user_login','method'=>'POST']); ?>

        <div class="form-group">
            <input type="email" name="email" class="form-control" placeholder="Email" required="">
        </div>
        <div class="form-group">
            <input type="password" name="password" class="form-control" placeholder="Password" required="">
        </div>
        <button type="submit" class="btn btn-primary block full-width m-b">Login</button>

        <a href="<?php echo e(route('user-forget-password')); ?>"><small>Forgot password?</small></a>
        <?php echo Form::close(); ?>

        <p class="m-t"> <small><strong>Copyright</strong> Dynamic Video&copy; 2014-2017</small> </p>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
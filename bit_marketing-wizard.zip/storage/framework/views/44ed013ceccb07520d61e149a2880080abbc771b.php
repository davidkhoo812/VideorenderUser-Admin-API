<!DOCTYPE html>
<html lang="en">

<!-- index.html  2016 00:22:55  -->
<head>
    <?php echo $__env->make('partials.auth.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="gray-bg">

<!--gt Wrapper Start-->
<div class="gt_wrapper">


    <!--Header Wrap Start-->
    <?php echo $__env->make('partials.auth.menubar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!--Header Wrap End-->

    <!--Main Content Wrap Start-->
    <?php echo $__env->yieldContent('content'); ?>
    <!--Main Content Wrap End-->

    <!--Footer Wrap Start-->
    <footer>
        <?php echo $__env->make('partials.auth.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
    <!--Footer Wrap End-->
    <!--Back to Top Wrap Start-->
    <div class="back-to-top">
        <a href="#home"><i class="fa fa-angle-up"></i></a>
    </div>
    <!--Back to Top Wrap Start-->

</div>
<!--gt Wrapper End-->

    <?php echo $__env->make('partials.auth.javascript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('scripts'); ?>
</body>

<!-- index.html  2016 00:24:52  -->
</html>

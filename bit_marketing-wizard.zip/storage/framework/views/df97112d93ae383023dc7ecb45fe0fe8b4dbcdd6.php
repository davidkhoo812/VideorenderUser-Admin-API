<h1>Your customer account succesfully created.</h1>
<div><?php echo e($bodyMessage); ?></div>
<p>Sent via <?php echo e($email); ?></p>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php echo $__env->make('admin.auth.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>

<body class="hold-transition login-page">
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('admin.auth.javascript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

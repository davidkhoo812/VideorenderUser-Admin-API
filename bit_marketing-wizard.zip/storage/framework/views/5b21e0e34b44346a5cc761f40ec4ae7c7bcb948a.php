<?php $__env->startSection('title', 'User Password Reset'); ?>

<?php $__env->startSection('content'); ?>

    <!--Main Content Wrap Start-->
    <div class="gt_main_content_wrap">
        <!--About Us Wrap Start-->
        <section class="gt_about_bg">
            <div class="container">
                <div class="row">
                    <div class="middle-box text-center animated fadeInDown">
                        <div>
                            <h1 class="logo-name">DV</h1>
                        </div>
                        <h3>User Password Reset</h3>
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-danger alert-dismissable">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <?php echo e(session()->get('message')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(Session::has('success')): ?>
                            <div class="alert alert-success" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <strong>Success ..! </strong> <?php echo e(Session::get('success')); ?>

                            </div>
                        <?php elseif(Session::has('error')): ?>
                            <div class="alert alert-danger" role="alert">
                                <strong>Error ..! </strong> <?php echo e(Session::get('error')); ?>

                            </div>
                        <?php elseif(count($errors) > 0): ?>
                            <div class="alert alert-danger" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                                <h4 class="text-center"><strong>Error ..! </strong> You have Something Error.</h4>
                                <ul class="text-center">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><p style="color: red"><?php echo $error; ?></p></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="gt_about_wrap" style="margin-bottom: 10px;">
                            <?php echo Form::open(['route'=>'user-reset-password-submit']); ?>


                            <input type="hidden" name="token" value="<?php echo e($token); ?>">
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <h5> Email : </h5>
                                </div>
                                <div class="col-md-8">
                                    <input type="email" name="email" placeholder="Enter Your Email Address" id="" class="form-control" style="border: 1px solid greenyellow" required>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <h5> New Password : </h5>
                                </div>
                                <div class="col-md-8">
                                    <input type="password" name="password" placeholder="Enter New Password" id="" class="form-control" style="border: 1px solid greenyellow" required>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <h5> Confirm Password : </h5>
                                </div>
                                <div class="col-md-8">
                                    <input type="password" name="password_confirmation" placeholder="Enter Confirm Password" id="" class="form-control" style="border: 1px solid greenyellow" required>
                                </div>
                            </div>
                            <br>

                            <div class="row">
                                <div class="col-md-8 col-md-offset-3">
                                    <input type="submit" value="Reset Password" class="btn btn-primary btn-block" style="margin-top: 10px">
                                </div>

                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                </div>
                
            </div>
        </section>
        <!--About Us Wrap End-->
    </div>
    <!--Main Content Wrap End-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TemplateVideos extends Model
{
    //
    //public $timestamps = false;

    protected $table = 'template_videos';
}
